import { BlockSchema, DefaultBlockSchema, DefaultInlineContentSchema, DefaultStyleSchema, InlineContentSchema, StyleSchema } from "@blocknote/core";
import { ComponentProps } from "../../editor/ComponentsContext.js";
import { FilePanelProps } from "./FilePanelProps.js";
type PanelProps = ComponentProps["FilePanel"]["Root"];
/**
 * By default, the FilePanel component will render with default tabs. However,
 * you can override the tabs to render by passing the `tabs` prop. You can use
 * the default tab panels in the `DefaultTabPanels` directory or make your own
 * using the `FilePanelPanel` component.
 */
export declare const FilePanel: <B extends BlockSchema = DefaultBlockSchema, I extends InlineContentSchema = DefaultInlineContentSchema, S extends StyleSchema = DefaultStyleSchema>(props: FilePanelProps<I, S> & Partial<Pick<PanelProps, "defaultOpenTab" | "tabs">>) => import("react/jsx-runtime").JSX.Element;
export {};
