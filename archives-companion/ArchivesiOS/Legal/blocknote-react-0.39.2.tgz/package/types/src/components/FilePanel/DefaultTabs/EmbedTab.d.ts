import { BlockSchema, DefaultBlockSchema, DefaultInlineContentSchema, DefaultStyleSchema, InlineContentSchema, StyleSchema } from "@blocknote/core";
import { FilePanelProps } from "../FilePanelProps.js";
export declare const EmbedTab: <B extends BlockSchema = DefaultBlockSchema, I extends InlineContentSchema = DefaultInlineContentSchema, S extends StyleSchema = DefaultStyleSchema>(props: FilePanelProps<I, S>) => import("react/jsx-runtime").JSX.Element;
