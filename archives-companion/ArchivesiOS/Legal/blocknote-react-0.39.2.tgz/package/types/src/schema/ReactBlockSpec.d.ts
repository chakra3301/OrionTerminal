import { BlockConfig, BlockNoDefaults, BlockNoteEditor, BlockNoteExtension, BlockSpec, CustomBlockImplementation, Props, PropSchema } from "@blocknote/core";
import { FC, ReactNode } from "react";
export type ReactCustomBlockRenderProps<TName extends string = string, TProps extends PropSchema = PropSchema, TContent extends "inline" | "none" = "inline" | "none"> = {
    block: BlockNoDefaults<Record<TName, BlockConfig<TName, TProps, TContent>>, any, any>;
    editor: BlockNoteEditor<Record<TName, BlockConfig<TName, TProps, TContent>>, any, any>;
    contentRef: (node: HTMLElement | null) => void;
};
export type ReactCustomBlockImplementation<TName extends string = string, TProps extends PropSchema = PropSchema, TContent extends "inline" | "none" = "inline" | "none"> = Omit<CustomBlockImplementation<TName, TProps, TContent>, "render" | "toExternalHTML"> & {
    render: FC<ReactCustomBlockRenderProps<TName, TProps, TContent>>;
    toExternalHTML?: FC<ReactCustomBlockRenderProps<TName, TProps, TContent>>;
};
export type ReactCustomBlockSpec<T extends string = string, PS extends PropSchema = PropSchema, C extends "inline" | "none" = "inline" | "none"> = {
    config: BlockConfig<T, PS, C>;
    implementation: ReactCustomBlockImplementation<T, PS, C>;
    extensions?: BlockNoteExtension<any>[];
};
export declare function BlockContentWrapper<BType extends string, PSchema extends PropSchema>(props: {
    blockType: BType;
    blockProps: Props<PSchema>;
    propSchema: PSchema;
    isFileBlock?: boolean;
    domAttributes?: Record<string, string>;
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
/**
 * Helper function to create a React block definition.
 * Can accept either functions that return the required objects, or the objects directly.
 */
export declare function createReactBlockSpec<const TName extends string, const TProps extends PropSchema, const TContent extends "inline" | "none", const TOptions extends Record<string, any> | undefined = undefined>(blockConfigOrCreator: BlockConfig<TName, TProps, TContent>, blockImplementationOrCreator: ReactCustomBlockImplementation<TName, TProps, TContent> | (TOptions extends undefined ? () => ReactCustomBlockImplementation<TName, TProps, TContent> : (options: Partial<TOptions>) => ReactCustomBlockImplementation<TName, TProps, TContent>), extensionsOrCreator?: BlockNoteExtension<any>[] | (TOptions extends undefined ? () => BlockNoteExtension<any>[] : (options: Partial<TOptions>) => BlockNoteExtension<any>[])): (options?: Partial<TOptions>) => BlockSpec<TName, TProps, TContent>;
export declare function createReactBlockSpec<const TName extends string, const TProps extends PropSchema, const TContent extends "inline" | "none", const BlockConf extends BlockConfig<TName, TProps, TContent>, const TOptions extends Partial<Record<string, any>>>(blockCreator: (options: Partial<TOptions>) => BlockConf, blockImplementationOrCreator: ReactCustomBlockImplementation<BlockConf["type"], BlockConf["propSchema"], BlockConf["content"]> | (TOptions extends undefined ? () => ReactCustomBlockImplementation<BlockConf["type"], BlockConf["propSchema"], BlockConf["content"]> : (options: Partial<TOptions>) => ReactCustomBlockImplementation<BlockConf["type"], BlockConf["propSchema"], BlockConf["content"]>), extensionsOrCreator?: BlockNoteExtension<any>[] | (TOptions extends undefined ? () => BlockNoteExtension<any>[] : (options: Partial<TOptions>) => BlockNoteExtension<any>[])): (options?: Partial<TOptions>) => BlockSpec<BlockConf["type"], BlockConf["propSchema"], BlockConf["content"]>;
