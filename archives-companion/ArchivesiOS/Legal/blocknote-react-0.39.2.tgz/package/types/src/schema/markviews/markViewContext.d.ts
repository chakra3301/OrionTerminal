import type { Mark } from "prosemirror-model";
import type { EditorView, MarkViewConstructor } from "prosemirror-view";
import type { ReactMarkViewUserOptions } from "./ReactMarkViewOptions.js";
export type MarkViewContentRef = (node: HTMLElement | null) => void;
export interface MarkViewContext {
    contentRef: MarkViewContentRef;
    view: EditorView;
    mark: Mark;
}
export declare const markViewContext: import("react").Context<MarkViewContext>;
export declare const useMarkViewContext: () => MarkViewContext;
export declare const createMarkViewContext: import("react").Context<(options: ReactMarkViewUserOptions) => MarkViewConstructor>;
export declare const useMarkViewFactory: () => (options: ReactMarkViewUserOptions) => MarkViewConstructor;
