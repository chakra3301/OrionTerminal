import { FileBlockConfig } from "@blocknote/core";
import { ReactCustomBlockRenderProps } from "../../../../schema/ReactBlockSpec.js";
export declare const FileNameWithIcon: (props: Omit<ReactCustomBlockRenderProps<FileBlockConfig["type"], FileBlockConfig["propSchema"], FileBlockConfig["content"]>, "editor" | "contentRef">) => import("react/jsx-runtime").JSX.Element;
