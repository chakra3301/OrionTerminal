import { Node, Schema, Slice } from "@tiptap/pm/model";
import type { Block } from "../../blocks/defaultBlocks.js";
import type { BlockSchema, InlineContent, InlineContentSchema, StyleSchema, TableContent } from "../../schema/index.js";
/**
 * Converts an internal (prosemirror) table node contentto a BlockNote Tablecontent
 */
export declare function contentNodeToTableContent<I extends InlineContentSchema, S extends StyleSchema>(contentNode: Node, inlineContentSchema: I, styleSchema: S): TableContent<I, S>;
/**
 * Converts an internal (prosemirror) content node to a BlockNote InlineContent array.
 */
export declare function contentNodeToInlineContent<I extends InlineContentSchema, S extends StyleSchema>(contentNode: Node, inlineContentSchema: I, styleSchema: S): InlineContent<I, S>[];
export declare function nodeToCustomInlineContent<I extends InlineContentSchema, S extends StyleSchema>(node: Node, inlineContentSchema: I, styleSchema: S): InlineContent<I, S>;
/**
 * Convert a Prosemirror node to a BlockNote block.
 *
 * TODO: test changes
 */
export declare function nodeToBlock<BSchema extends BlockSchema, I extends InlineContentSchema, S extends StyleSchema>(node: Node, schema: Schema, blockSchema?: BSchema, inlineContentSchema?: I, styleSchema?: S, blockCache?: import("../../index.js").BlockCache<any, any, any>): Block<BSchema, I, S>;
/**
 * Convert a Prosemirror document to a BlockNote document (array of blocks)
 */
export declare function docToBlocks<BSchema extends BlockSchema, I extends InlineContentSchema, S extends StyleSchema>(doc: Node, schema: Schema, blockSchema?: BSchema, inlineContentSchema?: I, styleSchema?: S, blockCache?: import("../../index.js").BlockCache<any, any, any>): Block<BSchema, I, S>[];
/**
 *
 * Parse a Prosemirror Slice into a BlockNote selection. The prosemirror schema looks like this:
 *
 * <blockGroup>
 *   <blockContainer> (main content of block)
 *       <p, heading, etc.>
 *   <blockGroup> (only if blocks has children)
 *     <blockContainer> (child block)
 *       <p, heading, etc.>
 *     </blockContainer>
 *    <blockContainer> (child block 2)
 *       <p, heading, etc.>
 *     </blockContainer>
 *   </blockContainer>
 *  </blockGroup>
 * </blockGroup>
 *
 */
export declare function prosemirrorSliceToSlicedBlocks<BSchema extends BlockSchema, I extends InlineContentSchema, S extends StyleSchema>(slice: Slice, schema: Schema, blockSchema?: BSchema, inlineContentSchema?: I, styleSchema?: S, blockCache?: WeakMap<Node, Block<BSchema, I, S>>): {
    /**
     * The blocks that are included in the selection.
     */
    blocks: Block<BSchema, I, S>[];
    /**
     * If a block was "cut" at the start of the selection, this will be the id of the block that was cut.
     */
    blockCutAtStart: string | undefined;
    /**
     * If a block was "cut" at the end of the selection, this will be the id of the block that was cut.
     */
    blockCutAtEnd: string | undefined;
};
