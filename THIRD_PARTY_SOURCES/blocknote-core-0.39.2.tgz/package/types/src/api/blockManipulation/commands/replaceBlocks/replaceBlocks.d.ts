import type { Transaction } from "prosemirror-state";
import type { Block, PartialBlock } from "../../../../blocks/defaultBlocks.js";
import type { BlockIdentifier, BlockSchema, InlineContentSchema, StyleSchema } from "../../../../schema/index.js";
export declare function removeAndInsertBlocks<BSchema extends BlockSchema, I extends InlineContentSchema, S extends StyleSchema>(tr: Transaction, blocksToRemove: BlockIdentifier[], blocksToInsert: PartialBlock<BSchema, I, S>[]): {
    insertedBlocks: Block<BSchema, I, S>[];
    removedBlocks: Block<BSchema, I, S>[];
};
