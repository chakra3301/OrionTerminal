import { redo, undo } from "@tiptap/pm/history";
import { Command, Transaction } from "prosemirror-state";
import { BlockNoteEditor } from "../BlockNoteEditor.js";
export declare class StateManager {
    private editor;
    private options?;
    constructor(editor: BlockNoteEditor, options?: {
        /**
         * Swap the default undo command with a custom command.
         */
        undo?: typeof undo;
        /**
         * Swap the default redo command with a custom command.
         */
        redo?: typeof redo;
    } | undefined);
    /**
     * Stores the currently active transaction, which is the accumulated transaction from all {@link dispatch} calls during a {@link transact} calls
     */
    private activeTransaction;
    /**
     * For any command that can be executed, you can check if it can be executed by calling `editor.can(command)`.
     * @example
     * ```ts
     * if (editor.can(editor.undo)) {
     *   // show button
     * } else {
     *   // hide button
     * }
     */
    can(cb: () => boolean): boolean;
    private isInCan;
    /**
     * Execute a prosemirror command. This is mostly for backwards compatibility with older code.
     *
     * @note You should prefer the {@link transact} method when possible, as it will automatically handle the dispatching of the transaction and work across blocknote transactions.
     *
     * @example
     * ```ts
     * editor.exec((state, dispatch, view) => {
     *   dispatch(state.tr.insertText("Hello, world!"));
     * });
     * ```
     */
    exec(command: Command): boolean;
    /**
     * Check if a command can be executed. A command should return `false` if it is not valid in the current state.
     *
     * @example
     * ```ts
     * if (editor.canExec(command)) {
     *   // show button
     * } else {
     *   // hide button
     * }
     * ```
     */
    canExec(command: Command): boolean;
    /**
     * Execute a function within a "blocknote transaction".
     * All changes to the editor within the transaction will be grouped together, so that
     * we can dispatch them as a single operation (thus creating only a single undo step)
     *
     * @note There is no need to dispatch the transaction, as it will be automatically dispatched when the callback is complete.
     *
     * @example
     * ```ts
     * // All changes to the editor will be grouped together
     * editor.transact((tr) => {
     *   tr.insertText("Hello, world!");
     * // These two operations will be grouped together in a single undo step
     *   editor.transact((tr) => {
     *     tr.insertText("Hello, world!");
     *   });
     * });
     * ```
     */
    transact<T>(callback: (
    /**
     * The current active transaction, this will automatically be dispatched to the editor when the callback is complete
     * If another `transact` call is made within the callback, it will be passed the same transaction as the parent call.
     */
    tr: Transaction) => T): T;
    /**
     * Get the underlying prosemirror state
     * @note Prefer using `editor.transact` to read the current editor state, as that will ensure the state is up to date
     * @see https://prosemirror.net/docs/ref/#state.EditorState
     */
    get prosemirrorState(): import("prosemirror-state").EditorState;
    /**
     * Get the underlying prosemirror view
     * @see https://prosemirror.net/docs/ref/#view.EditorView
     */
    get prosemirrorView(): import("prosemirror-view").EditorView;
    isFocused(): boolean;
    focus(): void;
    /**
     * Checks if the editor is currently editable, or if it's locked.
     * @returns True if the editor is editable, false otherwise.
     */
    get isEditable(): boolean;
    /**
     * Makes the editor editable or locks it, depending on the argument passed.
     * @param editable True to make the editor editable, or false to lock it.
     */
    set isEditable(editable: boolean);
    /**
     * Undo the last action.
     */
    undo(): boolean;
    /**
     * Redo the last action.
     */
    redo(): boolean;
}
