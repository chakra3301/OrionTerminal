import { BlockIdentifier, BlockSchema, InlineContentSchema, StyleSchema } from "../../schema/index.js";
import { DefaultBlockSchema, DefaultInlineContentSchema, DefaultStyleSchema } from "../../blocks/defaultBlocks.js";
import { Selection } from "../selectionTypes.js";
import { TextCursorPosition } from "../cursorPositionTypes.js";
import { BlockNoteEditor } from "../BlockNoteEditor.js";
export declare class SelectionManager<BSchema extends BlockSchema = DefaultBlockSchema, ISchema extends InlineContentSchema = DefaultInlineContentSchema, SSchema extends StyleSchema = DefaultStyleSchema> {
    private editor;
    constructor(editor: BlockNoteEditor<BSchema, ISchema, SSchema>);
    /**
     * Gets a snapshot of the current selection. This contains all blocks (included nested blocks)
     * that the selection spans across.
     *
     * If the selection starts / ends halfway through a block, the returned data will contain the entire block.
     */
    getSelection(): Selection<BSchema, ISchema, SSchema> | undefined;
    /**
     * Gets a snapshot of the current selection. This contains all blocks (included nested blocks)
     * that the selection spans across.
     *
     * If the selection starts / ends halfway through a block, the returned block will be
     * only the part of the block that is included in the selection.
     */
    getSelectionCutBlocks(): {
        blocks: import("../../index.js").Block<Record<string, import("../../index.js").BlockConfig<string, import("../../index.js").PropSchema, "inline" | "none" | "table">>, InlineContentSchema, StyleSchema>[];
        blockCutAtStart: string | undefined;
        blockCutAtEnd: string | undefined;
        _meta: {
            startPos: number;
            endPos: number;
        };
    };
    /**
     * Sets the selection to a range of blocks.
     * @param startBlock The identifier of the block that should be the start of the selection.
     * @param endBlock The identifier of the block that should be the end of the selection.
     */
    setSelection(startBlock: BlockIdentifier, endBlock: BlockIdentifier): void;
    /**
     * Gets a snapshot of the current text cursor position.
     * @returns A snapshot of the current text cursor position.
     */
    getTextCursorPosition(): TextCursorPosition<BSchema, ISchema, SSchema>;
    /**
     * Sets the text cursor position to the start or end of an existing block. Throws an error if the target block could
     * not be found.
     * @param targetBlock The identifier of an existing block that the text cursor should be moved to.
     * @param placement Whether the text cursor should be placed at the start or end of the block.
     */
    setTextCursorPosition(targetBlock: BlockIdentifier, placement?: "start" | "end"): void;
    /**
     * Gets the bounding box of the current selection.
     */
    getSelectionBoundingBox(): DOMRect | undefined;
}
