/**
 * Instead of depending on the NPM package, we vendor this file from https://github.com/n1ru4l/toposort/blob/main/src/toposort.ts (MIT)
 *
 * There was a recent publish, despite not having been updated in 2 years, which is suspicious.
 *
 * This file is also simple enough that we can maintain it ourselves.
 */
export type DirectedAcyclicGraph = Map<string, Iterable<string>>;
export type DependencyGraph = DirectedAcyclicGraph;
export type TaskList = Array<Set<string>>;
export type NodeId = string;
export type DependencyMap = Map<NodeId, Set<NodeId>>;
export declare function toposort(dag: DirectedAcyclicGraph): TaskList;
export declare function toposortReverse(deps: DependencyGraph): TaskList;
export declare function createDependencyGraph(): DependencyMap;
export declare function addDependency(graph: DependencyMap, from: NodeId, to: NodeId): DependencyMap;
export declare function removeDependency(graph: DependencyMap, from: NodeId, to: NodeId): boolean;
export declare function hasDependency(graph: DependencyMap, from: NodeId, to: NodeId): boolean;
