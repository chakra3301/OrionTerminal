export declare const TextColor: {
    config: {
        type: string;
        propSchema: "string";
    };
    implementation: import("../../index.js").StyleImplementation<{
        type: string;
        propSchema: "string";
    }>;
};
