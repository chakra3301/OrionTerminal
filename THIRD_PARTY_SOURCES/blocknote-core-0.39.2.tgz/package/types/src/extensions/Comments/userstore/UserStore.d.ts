import type { User } from "../../../comments/index.js";
import { EventEmitter } from "../../../util/EventEmitter.js";
/**
 * The `UserStore` is used to retrieve and cache information about users.
 *
 * It does this by calling `resolveUsers` (which is user-defined in the Editor Options)
 * for users that are not yet cached.
 */
export declare class UserStore<U extends User> extends EventEmitter<any> {
    private readonly resolveUsers;
    private userCache;
    private loadingUsers;
    constructor(resolveUsers: (userIds: string[]) => Promise<U[]>);
    /**
     * Load information about users based on an array of user ids.
     */
    loadUsers(userIds: string[]): Promise<void>;
    /**
     * Retrieve information about a user based on their id, if cached.
     *
     * The user will have to be loaded via `loadUsers` first
     */
    getUser(userId: string): U | undefined;
    /**
     * Subscribe to changes in the user store.
     *
     * @param cb - The callback to call when the user store changes.
     * @returns A function to unsubscribe from the user store.
     */
    subscribe(cb: (users: Map<string, U>) => void): () => void;
}
