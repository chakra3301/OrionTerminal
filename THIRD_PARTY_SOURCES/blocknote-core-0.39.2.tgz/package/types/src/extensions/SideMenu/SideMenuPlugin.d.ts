import { EditorState, PluginKey, PluginView } from "@tiptap/pm/state";
import { EditorView } from "@tiptap/pm/view";
import { Block } from "../../blocks/defaultBlocks.js";
import type { BlockNoteEditor } from "../../editor/BlockNoteEditor.js";
import { BlockNoteExtension } from "../../editor/BlockNoteExtension.js";
import { UiElementPosition } from "../../extensions-shared/UiElementPosition.js";
import { BlockSchema, InlineContentSchema, StyleSchema } from "../../schema/index.js";
export type SideMenuState<BSchema extends BlockSchema, I extends InlineContentSchema, S extends StyleSchema> = UiElementPosition & {
    block: Block<BSchema, I, S>;
};
/**
 * With the sidemenu plugin we can position a menu next to a hovered block.
 */
export declare class SideMenuView<BSchema extends BlockSchema, I extends InlineContentSchema, S extends StyleSchema> implements PluginView {
    private readonly editor;
    private readonly pmView;
    state?: SideMenuState<BSchema, I, S>;
    readonly emitUpdate: (state: SideMenuState<BSchema, I, S>) => void;
    private mousePos;
    private hoveredBlock;
    menuFrozen: boolean;
    isDragOrigin: boolean;
    constructor(editor: BlockNoteEditor<BSchema, I, S>, pmView: EditorView, emitUpdate: (state: SideMenuState<BSchema, I, S>) => void);
    updateState: (state: SideMenuState<BSchema, I, S>) => void;
    updateStateFromMousePos: () => void;
    /**
     * If a block is being dragged, ProseMirror usually gets the context of what's
     * being dragged from `view.dragging`, which is automatically set when a
     * `dragstart` event fires in the editor. However, if the user tries to drag
     * and drop blocks between multiple editors, only the one in which the drag
     * began has that context, so we need to set it on the others manually. This
     * ensures that PM always drops the blocks in between other blocks, and not
     * inside them.
     *
     * After the `dragstart` event fires on the drag handle, it sets
     * `blocknote/html` data on the clipboard. This handler fires right after,
     * parsing the `blocknote/html` data into nodes and setting them on
     * `view.dragging`.
     *
     * Note: Setting `view.dragging` on `dragover` would be better as the user
     * could then drag between editors in different windows, but you can only
     * access `dataTransfer` contents on `dragstart` and `drop` events.
     */
    onDragStart: (event: DragEvent) => void;
    /**
     * Finds the closest editor visually to the given coordinates
     */
    private findClosestEditorElement;
    /**
     * This dragover event handler listens at the document level,
     * and is trying to handle dragover events for all editors.
     *
     * It specifically is trying to handle the following cases:
     *  - If the dragover event is within the bounds of any editor, then it does nothing
     *  - If the dragover event is outside the bounds of any editor, but close enough (within DISTANCE_TO_CONSIDER_EDITOR_BOUNDS) to the closest editor,
     *    then it dispatches a synthetic dragover event to the closest editor (which will trigger the drop-cursor to be shown on that editor)
     *  - If the dragover event is outside the bounds of the current editor, then it will dispatch a synthetic dragleave event to the current editor
     *    (which will trigger the drop-cursor to be removed from the current editor)
     *
     * The synthetic event is a necessary evil because we do not control prosemirror-dropcursor to be able to show the drop-cursor within the range we want
     */
    onDragOver: (event: DragEvent) => void;
    /**
     * Closes the drop-cursor for the current editor
     */
    private closeDropCursor;
    /**
     * It is surprisingly difficult to determine the information we need to know about a drag event
     *
     * This function is trying to determine the following:
     *  - Whether the current editor instance is the drop point
     *  - Whether the current editor instance is the drag origin
     *  - Whether the drop event is within the bounds of the current editor instance
     */
    getDragEventContext: (event: DragEvent) => {
        isDropPoint: boolean;
        isDropWithinEditorBounds: boolean;
        isDragOrigin: boolean;
    } | undefined;
    /**
     * The drop event handler listens at the document level,
     * and handles drop events for all editors.
     *
     * It specifically handles the following cases:
     *  - If we are both the drag origin and drop point:
     *    - Let normal drop handling take over
     *  - If we are the drop point but not the drag origin:
     *    - Collapse selection to prevent PM from deleting unrelated content
     *    - If drop event is outside our editor bounds, dispatch synthetic drop event to our editor
     *  - If we are the drag origin but not the drop point:
     *    - Delete the dragged content from our editor after a delay
     */
    onDrop: (event: DragEvent) => void;
    onDragEnd: (event: DragEvent) => void;
    onKeyDown: (_event: KeyboardEvent) => void;
    onMouseMove: (event: MouseEvent) => void;
    private dispatchSyntheticEvent;
    onScroll: () => void;
    update(_view: EditorView, prevState: EditorState): void;
    destroy(): void;
}
export declare const sideMenuPluginKey: PluginKey<any>;
export declare class SideMenuProsemirrorPlugin<BSchema extends BlockSchema, I extends InlineContentSchema, S extends StyleSchema> extends BlockNoteExtension {
    private readonly editor;
    static key(): string;
    view: SideMenuView<BSchema, I, S> | undefined;
    constructor(editor: BlockNoteEditor<BSchema, I, S>);
    onUpdate(callback: (state: SideMenuState<BSchema, I, S>) => void): () => void;
    /**
     * Handles drag & drop events for blocks.
     */
    blockDragStart: (event: {
        dataTransfer: DataTransfer | null;
        clientY: number;
    }, block: Block<BSchema, I, S>) => void;
    /**
     * Handles drag & drop events for blocks.
     */
    blockDragEnd: () => void;
    /**
     * Freezes the side menu. When frozen, the side menu will stay
     * attached to the same block regardless of which block is hovered by the
     * mouse cursor.
     */
    freezeMenu: () => void;
    /**
     * Unfreezes the side menu. When frozen, the side menu will stay
     * attached to the same block regardless of which block is hovered by the
     * mouse cursor.
     */
    unfreezeMenu: () => void;
}
