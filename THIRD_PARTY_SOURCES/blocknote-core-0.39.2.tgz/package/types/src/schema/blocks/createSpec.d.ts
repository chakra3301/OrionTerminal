import { Editor } from "@tiptap/core";
import { TagParseRule } from "@tiptap/pm/model";
import { NodeView } from "@tiptap/pm/view";
import { BlockNoteExtension } from "../../editor/BlockNoteExtension.js";
import { PropSchema } from "../propTypes.js";
import { BlockConfig, BlockImplementation, BlockSpec, LooseBlockSpec } from "./types.js";
export declare function applyNonSelectableBlockFix(nodeView: NodeView, editor: Editor): void;
export declare function getParseRules<TName extends string, TProps extends PropSchema, TContent extends "inline" | "none" | "table">(config: BlockConfig<TName, TProps, TContent>, implementation: BlockImplementation<TName, TProps, TContent>): TagParseRule[];
export declare function addNodeAndExtensionsToSpec<TName extends string, TProps extends PropSchema, TContent extends "inline" | "none" | "table">(blockConfig: BlockConfig<TName, TProps, TContent>, blockImplementation: BlockImplementation<TName, TProps, TContent>, extensions?: BlockNoteExtension<any>[], priority?: number): LooseBlockSpec<TName, TProps, TContent>;
/**
 * Helper function to create a block config.
 */
export declare function createBlockConfig<TCallback extends (options: Partial<Record<string, any>>) => BlockConfig<any, any, any>, TOptions extends Parameters<TCallback>[0], TName extends ReturnType<TCallback>["type"], TProps extends ReturnType<TCallback>["propSchema"], TContent extends ReturnType<TCallback>["content"]>(callback: TCallback): TOptions extends undefined ? () => BlockConfig<TName, TProps, TContent> : (options: TOptions) => BlockConfig<TName, TProps, TContent>;
/**
 * Helper function to create a block definition.
 * Can accept either functions that return the required objects, or the objects directly.
 */
export declare function createBlockSpec<const TName extends string, const TProps extends PropSchema, const TContent extends "inline" | "none", const TOptions extends Partial<Record<string, any>> | undefined = undefined>(blockConfigOrCreator: BlockConfig<TName, TProps, TContent>, blockImplementationOrCreator: BlockImplementation<TName, TProps, TContent> | (TOptions extends undefined ? () => BlockImplementation<TName, TProps, TContent> : (options: Partial<TOptions>) => BlockImplementation<TName, TProps, TContent>), extensionsOrCreator?: BlockNoteExtension<any>[] | (TOptions extends undefined ? () => BlockNoteExtension<any>[] : (options: Partial<TOptions>) => BlockNoteExtension<any>[])): (options?: Partial<TOptions>) => BlockSpec<TName, TProps, TContent>;
export declare function createBlockSpec<const TName extends string, const TProps extends PropSchema, const TContent extends "inline" | "none", const BlockConf extends BlockConfig<TName, TProps, TContent>, const TOptions extends Partial<Record<string, any>>>(blockCreator: (options: Partial<TOptions>) => BlockConf, blockImplementationOrCreator: BlockImplementation<BlockConf["type"], BlockConf["propSchema"], BlockConf["content"]> | (TOptions extends undefined ? () => BlockImplementation<BlockConf["type"], BlockConf["propSchema"], BlockConf["content"]> : (options: Partial<TOptions>) => BlockImplementation<BlockConf["type"], BlockConf["propSchema"], BlockConf["content"]>), extensionsOrCreator?: BlockNoteExtension<any>[] | (TOptions extends undefined ? () => BlockNoteExtension<any>[] : (options: Partial<TOptions>) => BlockNoteExtension<any>[])): (options?: Partial<TOptions>) => BlockSpec<BlockConf["type"], BlockConf["propSchema"], BlockConf["content"]>;
