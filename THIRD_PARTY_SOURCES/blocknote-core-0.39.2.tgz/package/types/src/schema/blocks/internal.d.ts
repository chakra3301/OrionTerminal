import { Attributes, Editor, Node } from "@tiptap/core";
import type { BlockNoteEditor } from "../../editor/BlockNoteEditor.js";
import { BlockNoteExtension } from "../../editor/BlockNoteExtension.js";
import { InlineContentSchema } from "../inlineContent/types.js";
import { PropSchema, Props } from "../propTypes.js";
import { StyleSchema } from "../styles/types.js";
import { BlockConfig, BlockSchemaWithBlock, LooseBlockSpec, SpecificBlock } from "./types.js";
export declare function propsToAttributes(propSchema: PropSchema): Attributes;
export declare function getBlockFromPos<BType extends string, Config extends BlockConfig, BSchema extends BlockSchemaWithBlock<BType, Config>, I extends InlineContentSchema, S extends StyleSchema>(getPos: () => number | undefined, editor: BlockNoteEditor<BSchema, I, S>, tipTapEditor: Editor, type: BType): SpecificBlock<BSchema, BType, I, S>;
export declare function wrapInBlockStructure<BType extends string, PSchema extends PropSchema>(element: {
    dom: HTMLElement | DocumentFragment;
    contentDOM?: HTMLElement;
    destroy?: () => void;
}, blockType: BType, blockProps: Partial<Props<PSchema>>, propSchema: PSchema, isFileBlock?: boolean, domAttributes?: Record<string, string>): {
    dom: HTMLElement;
    contentDOM?: HTMLElement;
    destroy?: () => void;
};
export declare function createBlockSpecFromTiptapNode<const T extends {
    node: Node;
    type: string;
    content: "inline" | "table" | "none";
}, P extends PropSchema>(config: T, propSchema: P, extensions?: BlockNoteExtension<any>[]): LooseBlockSpec<T["type"], P, T["content"]>;
